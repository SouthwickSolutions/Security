*** HowTo-
https://4sysops.com/archives/how-to-install-the-powershell-console-extension-psreadline/#installing-on-windows-81-with-powershell-4

*** Module Site-
https://github.com/lzybkr/PSReadLine/releases

*** For Windows 8.1, download "PSReadLine - Latest" from the above site

*** Module must be in the following path-
C:\Users\<User>\Documents\WindowsPowerShell\Modules\PSReadLine